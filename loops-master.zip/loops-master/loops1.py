#!/usr/bin/python
# what is this doing? 
for x in range(0, 8):
    for y in range(0, 16):
      print x, y
      
        
  
