#!/usr/bin/python
# how is this?
import random

number =int(random.randint(1,6)) 
print number
